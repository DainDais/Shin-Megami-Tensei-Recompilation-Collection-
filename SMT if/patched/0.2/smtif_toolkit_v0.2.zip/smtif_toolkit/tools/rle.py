"""RLE image codec (magic 0x102) used by SMT if... (PS1) graphics.

Header: u32 0x102, u32 packed_size?, u32 0, u16 width_in_halfwords, u16 height, then stream:
  c < 0x80  -> c+1 literal bytes
  c >= 0x80 -> repeat next byte (c - 0x80 + 3) times   (verified against block sizes)
"""
import struct


def decode(src, pos=0, run_bias=3):
    magic, size, z = struct.unpack_from('<III', src, pos)
    w, h = struct.unpack_from('<HH', src, pos + 12)
    need = w * 2 * h
    p = pos + 16
    out = bytearray()
    while len(out) < need:
        c = src[p]
        p += 1
        if c < 0x80:
            out += src[p:p + c + 1]
            p += c + 1
        else:
            out += bytes([src[p]]) * (c - 0x80 + run_bias)
            p += 1
    return w, h, bytes(out[:need]), p - pos


def encode(width_halfwords, height, pixels):
    """Encode raw image bytes (width_halfwords*2*height) into a 0x102 RLE block."""
    import struct
    data = bytes(pixels)
    out = bytearray()
    lit = bytearray()
    i, n = 0, len(data)

    def flush():
        nonlocal lit
        while lit:
            chunk = lit[:128]
            out.append(len(chunk) - 1)
            out.extend(chunk)
            lit = lit[128:]
    while i < n:
        j = i
        while j < n and j - i < 130 and data[j] == data[i]:
            j += 1
        if j - i >= 3:
            flush()
            out.append(0x80 + (j - i) - 3)
            out.append(data[i])
            i = j
        else:
            lit.append(data[i])
            i += 1
    flush()
    return struct.pack('<IIIHH', 0x102, len(out) + 16, 0, width_halfwords, height) + bytes(out)
