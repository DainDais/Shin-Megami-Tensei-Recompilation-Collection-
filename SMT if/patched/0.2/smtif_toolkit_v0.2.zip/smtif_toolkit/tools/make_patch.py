#!/usr/bin/env python3
"""Build the English patch.

Usage: make_patch.py <original.bin> <out.bin>

- Event text (D/F0016.BIN) goes through f16pack: any text block may grow; the file is repacked,
  the scene index in the exe is rewritten, and if F0016 outgrows its slot on disc it is moved into
  the zero-filled ZZZ.BIN area (FILEPOS.DAT + ISO directory updated).
- Other string tables (e.g. menus in F0017) are replaced in place within their sector slot.
- English tiles are drawn into the dialogue font (F0013) and the menu font (F0014, bit-plane packed).
"""
import glob
import json
import os
import re
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import enfont  # noqa: E402
import en_insert as E  # noqa: E402
import f16pack  # noqa: E402
from menufont import MenuFont  # noqa: E402
from build import Builder, file_table  # noqa: E402
from cdsector import SECTOR, fix_form1  # noqa: E402
from font import load_font, set_glyph, build_f0013  # noqa: E402
from lz import pack_block, decompress, compress  # noqa: E402
from relocate import set_record, write_file_at  # noqa: E402
from smtext import TABLE  # noqa: E402

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
WIDTH_TABLE = 0xe3680              # dialogue width table (RAM 0x800F2E80)
MENU_METRICS = 0xe3110             # menu metrics table (RAM 0x800F2910): hi=trim, lo=width
GAP_PATCHES = [0x3a930, 0x4bb9c]   # dialogue 'addiu v1, s4/s6, 1' -> 0 : 1px letter spacing
TILE_BUDGET = 600                  # fewer tiles = fewer kanji slots taken from untranslated text
MENU_W = 135
MENU_MAX_CODES = 11               # longest original menu string; longer ones overflow and hang the game
FILEPOS_LBA = 23
F0016_INDEX = 16                   # entry in FILEPOS.DAT

# in-place string tables: file, block offset, slot end, translation, kind
INPLACE = [
    ('D/F0017.BIN', 0x0000, 0x1000, 'F0017_b0.json', 'menu'),
]
# map-event files laid out like F0016 units (script block + text block per sector-aligned unit, no index):
# each text block may grow up to the start of the next block, so units never move.
INPLACE_FILES = ['F0018']


def discover_inplace():
    jobs = list(INPLACE)
    for name in INPLACE_FILES:
        d = json.load(open(os.path.join(ROOT, 'script', f'{name}.json'), encoding='utf-8'))
        size = os.path.getsize(os.path.join(ROOT, 'disc', 'D', f'{name}.BIN'))
        offs = [b['offset'] for b in d['blocks']] + [size]
        for k, b in enumerate(d['blocks']):
            t = f"{name}_o{b['offset']:05x}.json"
            if os.path.exists(os.path.join(ROOT, 'trans', t)):
                jobs.append((f'D/{name}.BIN', b['offset'], offs[k + 1], t, 'dialogue'))
    return jobs


def read_table(data, off):
    m, csz, usz = struct.unpack_from('<III', data, off)
    out, _ = decompress(data, off + 12, usz)
    return f16pack.parse_table(out)


def load_translation(path, kind):
    tr = json.load(open(path, encoding='utf-8'))
    toks = {}
    for k, v in tr.items():
        if k.startswith('_'):
            continue
        t = E.parse(v)
        if kind == 'dialogue':
            t = E.wrap(t)
            lines, w = E.page_stats(t)
            if lines > 3 or w > E.LINE_W:
                print(f'  WARN {os.path.basename(path)}:{k}: {lines} lines/page, {w}px')
        else:
            w = sum(E.tok_width(x) for x in t)
            if w > MENU_W:
                print(f'  WARN {os.path.basename(path)}:{k}: menu text {w}px > {MENU_W}')
        toks[int(k)] = t
    return toks


def main():
    orig, outp = sys.argv[1], sys.argv[2]
    exe = bytearray(open(os.path.join(ROOT, 'disc', 'SLPM_871.53'), 'rb').read())
    f16 = open(os.path.join(ROOT, 'disc', 'D', 'F0016.BIN'), 'rb').read()
    units, end_marker = f16pack.load(bytes(exe), f16)
    by_off = {u['off']: u for u in units}

    # ---- collect translations
    f16_jobs = []
    for path in sorted(glob.glob(os.path.join(ROOT, 'trans', 'F0016_u*_b*.json'))):
        m = re.search(r'F0016_u([0-9a-f]+)_b(\d+)\.json$', path)
        uoff, bidx = int(m.group(1), 16), int(m.group(2))
        strings = f16pack.parse_table(by_off[uoff]['blocks'][bidx]['payload'])
        f16_jobs.append((uoff, bidx, strings, load_translation(path, 'dialogue'), os.path.basename(path)))
    files = {}
    inplace_jobs = []
    for path, off, end, tname, kind in discover_inplace():
        if path not in files:
            files[path] = bytearray(open(os.path.join(ROOT, 'disc', path), 'rb').read())
        strings = read_table(files[path], off)
        inplace_jobs.append((path, off, end, tname, strings, load_translation(os.path.join(ROOT, 'trans', tname), kind), kind))

    corpus = [r for j in f16_jobs for t in j[3].values() for r in E.runs(t) if isinstance(r, str)]
    corpus += [r for j in inplace_jobs for t in j[5].values() for r in E.runs(t) if isinstance(r, str)]
    tiles = E.build_tiles(corpus, TILE_BUDGET)
    # kanji still needed = whole-disc usage minus the Japanese lines being replaced
    usage = json.load(open(os.path.join(ROOT, 'tools', 'glyph_usage.json')))
    gone = {}
    for j in f16_jobs:
        for i in j[3]:
            for c in j[2][i]:
                gone[c] = gone.get(c, 0) + 1
    for j in inplace_jobs:
        for i in j[5]:
            for c in j[4][i]:
                gone[c] = gone.get(c, 0) + 1
    rest = {k: max(0, v - gone.get(int(k, 16), 0)) for k, v in usage.items()}
    slots = E.slot_order(rest)
    tilecodes = {t: slots[k] for k, t in enumerate(tiles)}
    print(f'tiles: {len(tiles)} (reusing kanji slots still used <= '
          f'{max(rest.get(f"{slots[k]:04x}", 0) for k in range(len(tiles)))}x by untranslated text)')

    # ---- F0016 event text
    nlines = 0
    for uoff, bidx, strings, toks, name in f16_jobs:
        codes = [list(s) for s in strings]
        for i, t in toks.items():
            codes[i] = E.encode_string(t, tilecodes)
        nlines += len(toks)
        order = E.best_order(codes, compress)
        f16pack.replace_text(by_off[uoff], bidx, E.pack_table_ordered(codes, order))
    new16, index = f16pack.repack(units, end_marker)
    print(f'F0016: {len(f16_jobs)} text blocks, {nlines} lines translated; size {len(new16):#x} (was {len(f16):#x})')
    for k, v in enumerate(index):
        struct.pack_into('<I', exe, f16pack.EXE_INDEX + 4 * k, v)

    # ---- in-place tables
    for path, off, end, tname, strings, toks, kind in inplace_jobs:
        codes = [list(s) for s in strings]
        for i, t in toks.items():
            codes[i] = E.encode_string(t, tilecodes)
            if kind == 'menu' and len(codes[i]) > MENU_MAX_CODES:
                raise SystemExit(f'{tname}:{i}: menu string needs {len(codes[i])} glyphs > {MENU_MAX_CODES}; shorten it')
        order = E.best_order(codes, compress)
        payload = E.pack_table_ordered(codes, order)
        if len(payload) > f16pack.MAX_TEXT_USIZE:
            raise SystemExit(f'{tname}: text {len(payload)} > {f16pack.MAX_TEXT_USIZE}')
        blk = pack_block(payload)
        room = end - off
        print(f'{tname}: {len(toks)} lines translated, packed {len(blk)} / room {room}')
        if len(blk) > room:
            raise SystemExit(f'{tname} DOES NOT FIT')
        files[path][off:end] = blk + bytes(room - len(blk))

    # ---- fonts + metrics
    f13 = open(os.path.join(ROOT, 'disc', 'D', 'F0013.BIN'), 'rb').read()
    font = load_font(f13)
    mf = MenuFont(open(os.path.join(ROOT, 'disc', 'D', 'F0014.BIN'), 'rb').read())
    for t, code in tilecodes.items():
        px, W = enfont.render_tile(t)
        set_glyph(font, code, px)
        exe[WIDTH_TABLE + code] = max(1, W)
        exe[MENU_METRICS + code] = min(15, max(0, W))
        rows = [[1 if px[y + 1][x] != 3 else 0 for x in range(12)] for y in range(11)] + [[0] * 12]
        mf.set(code, rows)
    for off in GAP_PATCHES:
        assert exe[off:off + 2] == b'\x01\x00', exe[off:off + 4].hex()
        exe[off:off + 2] = b'\x00\x00'

    # ---- assemble disc
    b = Builder(orig, outp)
    for path, data in files.items():
        b.replace(path, bytes(data))
    b.replace('D/F0013.BIN', build_f0013(font, f13))
    b.replace('D/F0014.BIN', mf.build())
    b.replace('SLPM_871.53', bytes(exe))
    ft = file_table()
    lba16, size16 = ft['D/F0016.BIN']
    relocate = len(new16) > (size16 + 2047) // 2048 * 2048
    if not relocate:
        b.replace('D/F0016.BIN', new16)
    b.finish()
    if relocate:
        zlba, zsize = ft['ZZZ.BIN']
        with open(outp, 'r+b') as f:
            n = write_file_at(f, zlba, new16)
            set_record(f, 'D/F0016.BIN', zlba, len(new16))
            set_record(f, 'ZZZ.BIN', zlba + n, zsize - n * 2048)
            f.seek(FILEPOS_LBA * SECTOR)
            raw = bytearray(f.read(SECTOR))
            struct.pack_into('<II', raw, 24 + F0016_INDEX * 8, zlba, len(new16))
            f.seek(FILEPOS_LBA * SECTOR)
            f.write(fix_form1(raw))
        print(f'  F0016 relocated to LBA {zlba} ({n} sectors); FILEPOS.DAT and ISO directory updated')
    json.dump(tilecodes, open(os.path.join(ROOT, 'trans', 'tiles.json'), 'w'), ensure_ascii=False, indent=0)


if __name__ == '__main__':
    main()
