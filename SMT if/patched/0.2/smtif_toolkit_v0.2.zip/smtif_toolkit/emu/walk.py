"""walk.py <state_in> <state_out> <prefix> <moves...>   moves: U D L R C(ircle) X(cross) T(riangle) S(quare) W(wait)"""
import sys
sys.path.insert(0, '/home/claude/emu')
from emu import Emu
M = {'U': 'UP', 'D': 'DOWN', 'L': 'LEFT', 'R': 'RIGHT', 'C': 'CIRCLE', 'X': 'CROSS', 'T': 'TRIANGLE', 'S': 'SQUARE',
     'A': 'L', 'B': 'R', 'P': 'START', 'E': 'SELECT'}
e = Emu('/home/claude/emu/pcsx_rearmed/pcsx_rearmed_libretro.so', '/home/claude/emu/game/school.cue')
e.load(sys.argv[1])
e.cdlog()
F18 = (4029, 4045)
for i, m in enumerate(sys.argv[4:]):
    if m == 'W':
        e.run(60)
    else:
        e.run(4, M[m]); e.run(int(__import__("os").environ.get("WAITF", "40")))
    log = e.cdlog()
    hits = [x - F18[0] for x in log if F18[0] <= x < F18[1]]
    f16 = [x for x in log if x >= 95371]
    if hits or f16:
        print(i, m, 'F0018 sectors', sorted(set(hits)), 'F0016 reloc', (min(f16), max(f16)) if f16 else '')
    e.shot(f'shots/s/{sys.argv[3]}{i:03d}.png', 1)
e.save(sys.argv[2])
