"""Minimal GP0 packet parser."""
def s11(v):
    v &= 0x7ff
    return v - 0x800 if v & 0x400 else v

def xy(w):
    return s11(w), s11(w >> 16)

def parse(words):
    out = []
    i = 0
    off = (0, 0)
    tpage = 0
    while i < len(words):
        w = words[i]; c = w >> 24
        def take(n):
            return words[i:i + n]
        if c == 0xe5:
            off = (s11(w), s11(w >> 11)); i += 1; continue
        if c == 0xe1:
            tpage = w & 0x7ff; i += 1; continue
        if 0x20 <= c < 0x40:
            gour, quad, tex = c & 0x10, c & 0x08, c & 0x04
            nv = 4 if quad else 3
            per = 1 + (1 if tex else 0) + (1 if gour else 0)
            n = 1 + nv * per - (1 if gour else 0)
            pk = take(n)
            verts = []
            p = 1
            for v in range(nv):
                if gour and v > 0: p += 1
                verts.append(xy(pk[p])); p += 1
                if tex: p += 1
            out.append(('poly', c, [(x + off[0], y + off[1]) for x, y in verts], pk, tpage)); i += n; continue
        if 0x40 <= c < 0x60:
            if c & 0x08:  # polyline
                j = i + 1
                while j < len(words) and (words[j] & 0xf000f000) != 0x50005000: j += 1
                i = j + 1; continue
            n = 4 if c & 0x10 else 3
            i += n; continue
        if 0x60 <= c < 0x80:
            tex = c & 0x04; size = (c >> 3) & 3
            n = 2 + (1 if tex else 0) + (1 if size == 0 else 0)
            pk = take(n)
            x, y = xy(pk[1]); x += off[0]; y += off[1]
            if size == 0: wh = (pk[-1] & 0xffff, pk[-1] >> 16)
            else: wh = {1: (1, 1), 2: (8, 8), 3: (16, 16)}[size]
            uv = (pk[2] & 0xff, (pk[2] >> 8) & 0xff, pk[2] >> 16) if tex else None
            out.append(('rect', c, (x, y, wh[0], wh[1]), uv, tpage)); i += n; continue
        if c == 0xa0:
            wh = words[i + 2]; ww, hh = wh & 0xffff, wh >> 16
            out.append(('upload', c, (words[i + 1] & 0xffff, words[i + 1] >> 16, ww, hh), None, tpage))
            i += 3 + (ww * hh + 1) // 2; continue
        if c == 0x80: out.append(('copy', c, words[i + 1:i + 4], None, tpage)); i += 4; continue
        if c == 0xc0: i += 3; continue
        if c == 0x02: out.append(('fill', c, (xy(words[i+1]), words[i+2]), None, tpage)); i += 3; continue
        i += 1
    return out
